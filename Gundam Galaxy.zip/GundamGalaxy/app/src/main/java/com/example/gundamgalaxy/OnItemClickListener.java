package com.example.gundamgalaxy;

public interface OnItemClickListener {
    void onItemClicked(int position);
}
